package com.example.cs360_project_2_inventory_app_francisco_sousa;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private GridView gridView;
    private ArrayList<HashMap<String, String>> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        db = new DatabaseHelper(this);
        gridView = findViewById(R.id.gridView);
        loadItems();

        gridView.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            HashMap<String, String> item = itemList.get(position);
            if (item == null) return;

            String idStr = item.get("id");
            String qtyStr = item.get("qty");
            String name = item.get("name");

            if (idStr == null || qtyStr == null || name == null) return;

            int itemId = Integer.parseInt(idStr);
            int qty = Integer.parseInt(qtyStr);

            if (qty > 1) {
                db.updateItem(itemId, name, qty - 1);
                Toast.makeText(this, "Decreased quantity for " + name, Toast.LENGTH_SHORT).show();
            } else {
                db.deleteItem(itemId);
                Toast.makeText(this, "Deleted " + name, Toast.LENGTH_SHORT).show();
            }
            loadItems();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }

    public void onAddItemClick(View v) {
        startActivity(new Intent(this, AddItemActivity.class));
    }

    public void onRefreshClick(View v) {
        loadItems();
        Toast.makeText(this, "Inventory refreshed", Toast.LENGTH_SHORT).show();
    }

    private void loadItems() {
        Cursor c = db.getAllItems();
        itemList = new ArrayList<>();

        if (c.getCount() == 0) {
            Toast.makeText(this, "No items found", Toast.LENGTH_SHORT).show();
        } else {
            while (c.moveToNext()) {
                HashMap<String, String> map = new HashMap<>();
                int id = c.getInt(0);
                String name = c.getString(1);
                int qty = c.getInt(2);
                map.put("id", String.valueOf(id));
                map.put("name", name);
                map.put("qty", String.valueOf(qty));
                itemList.add(map);

                if (qty < 5 && checkSelfPermission(Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED) {
                    sendLowStockAlert(name, qty);
                }
            }
        }
        c.close();

        SimpleAdapter adapter = new SimpleAdapter(
                this,
                itemList,
                android.R.layout.simple_list_item_2,
                new String[]{"name", "qty"},
                new int[]{android.R.id.text1, android.R.id.text2}
        );
        gridView.setAdapter(adapter);
    }

    private void sendLowStockAlert(@NonNull String name, int qty) {
        try {
            // Updated for Android 12+ compatibility
            SmsManager sms = getSystemService(SmsManager.class);
            if (sms != null) {
                sms.sendTextMessage("+15551234567", null,
                        "Alert: " + name + " stock is low (" + qty + " left)", null, null);
            } else {
                Toast.makeText(this, "SMS service unavailable", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}

