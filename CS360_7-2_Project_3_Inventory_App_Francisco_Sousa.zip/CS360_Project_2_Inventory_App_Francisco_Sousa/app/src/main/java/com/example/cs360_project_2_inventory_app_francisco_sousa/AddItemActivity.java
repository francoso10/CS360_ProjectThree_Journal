package com.example.cs360_project_2_inventory_app_francisco_sousa;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private EditText etItemName, etItemQty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        db = new DatabaseHelper(this);
        etItemName = findViewById(R.id.etItemName);
        etItemQty = findViewById(R.id.etItemQty);
    }

    // Called when user taps Save
    public void onSaveClick(View v) {
        String name = etItemName.getText().toString().trim();
        String qtyStr = etItemQty.getText().toString().trim();

        if (name.isEmpty() || qtyStr.isEmpty()) {
            Toast.makeText(this, "Enter both name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(qtyStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = db.insertItem(name, quantity);
        if (success) {
            Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error adding item", Toast.LENGTH_SHORT).show();
        }

        finish(); // Return to Inventory screen
    }
}
