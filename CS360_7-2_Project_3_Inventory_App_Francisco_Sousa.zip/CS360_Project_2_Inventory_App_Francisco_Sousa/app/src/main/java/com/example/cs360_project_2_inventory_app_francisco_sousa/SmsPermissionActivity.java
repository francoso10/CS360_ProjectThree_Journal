package com.example.cs360_project_2_inventory_app_francisco_sousa;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;


public class SmsPermissionActivity extends AppCompatActivity {

    private static final int REQ_SMS = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);
        updateStatus();
    }

    public void onEnableSmsClick(View v) {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            updateStatus();
        } else {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SMS) {
            updateStatus();
        }
    }

    private void updateStatus() {
        TextView tv = findViewById(R.id.tvSmsStatus);
        boolean granted = checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        tv.setText(granted ? "SMS permission: Granted" : "SMS permission: Denied");
    }

    // Continue button handler
    public void onContinueClick(View v) {
        startActivity(new Intent(this, InventoryActivity.class));
        finish();
    }
}
