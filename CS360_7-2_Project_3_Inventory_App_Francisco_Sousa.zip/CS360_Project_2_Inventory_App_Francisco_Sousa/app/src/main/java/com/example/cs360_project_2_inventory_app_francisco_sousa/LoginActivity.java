package com.example.cs360_project_2_inventory_app_francisco_sousa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class LoginActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private EditText etUsername, etPassword;
    private boolean creating = false; // tracks mode

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DatabaseHelper(this);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
    }

    // Sign In button
    public void onSignInClick(View v) {
        if (creating) {
            Toast.makeText(this, "Finish creating your account first", Toast.LENGTH_SHORT).show();
            return;
        }

        String username = getText(etUsername);
        String password = getText(etPassword);

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (db.checkUser(username, password)) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, InventoryActivity.class));
        } else {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }

    // Create Account button toggles mode or registers new user
    public void onCreateAccountClick(View v) {
        MaterialButton btn = (MaterialButton) v;
        TextView title = findViewById(R.id.tvTitle);

        if (!creating) {
            // Switch to registration mode
            creating = true;
            btn.setText("Register");
            title.setText("Create New Account");
            Toast.makeText(this, "Enter new username and password, then tap Register", Toast.LENGTH_SHORT).show();
        } else {
            // Perform registration
            String username = getText(etUsername);
            String password = getText(etPassword);

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean created = db.insertUser(username, password);
            if (created) {
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, SmsPermissionActivity.class));
            } else {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            }

            // Reset to login mode
            creating = false;
            btn.setText("Create Account");
            title.setText("Inventory App Login");
        }
    }

    private String getText(EditText e) {
        return e.getText() != null ? e.getText().toString().trim() : "";
    }
}
